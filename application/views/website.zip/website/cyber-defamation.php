<section class="find-job cyber section inner-articles">
<div class="container">
<h2 class="section-title">Cyber Defamation</h2>
<div class="dotted-border">
<div class="dotted-line"></div>
<div class="dotted-line"></div>
<div class="dotted-line"></div>
</div>
<div class="row">
<div class="col-md-9">
<div id="">		
					
<p>This Website acknowledge the seriousness of Cyber Defamation, and will take all the necessary
legal actions against any person who violates the cyber defamation regulation. Generally,
defamation is a false and unprivileged statement of fact that is harmful to someone's reputation,
and published "with fault," meaning as a result of negligence or malice. The elements of a cyber-
defamation claim are essentially the same as a traditional defamation claim and typically include:
a false and defamatory statement concerning another; an unprivileged publication to a third
party; fault amounting at least to negligence on the part of the publisher; and either actionability
of the statement irrespective of special harm or the existence of special harm caused by the
publication. For further information about cyber defamation, please check Communication and
information technology commission regulation. 
</p>
<br />
<!--<blockquote>-->
    <p>We all need to be very responsible and  respectful Citizens and always ensure that the Contents posted on All social Media namely</p>
<!--</blockquote>-->
<!--<hr class="dark-grey" />-->
<!--<h3>The following are the Mediums by which Cyber Defamtion can be Happen</h3>-->
<ol>
   <li>Watsapp groups</li>
   <li>Twitter</li>
   <li>Instagram, Etc</li>
</ol>
<p>Does not cause any embarrassment to Other people and we don't spread misery and False news which divide people and cause panic in the society</p>

</div>
</div>


</div>
</div>
</section>

﻿<div id="content">
    <div class="container">
        <div class="row">
            <div class="col-md-9">
                <div class="blog-post">
                    <div class="post-thumb">
                        <a href="#"><img src="<?=base_url($news_details->image)?>"" alt=""></a>
                        <div class="hover-wrap">
                        </div>
                    </div>
                    <div class="post-content">
                        <h3 class="post-title"><a href="#"><?=$news_details->title_arbic?></a></h3>
                        <div class="meta">
                            <span class="meta-part"><i class="ti-calendar"></i><a href="#"><?=date('Y-m-d',strtotime($news_details->created_on));?></a></span>
                        </div>
                        <p><?=$news_details->description_arbic?></p>
                        <div class="share-social">
                            <span>Share This News</span>
                            <div class="social-link">
                                <a class="share" target="_blank" data-original-title="Share" href="#" data-toggle="tooltip" data-placement="top"><i class="fa fa-share-alt"></i></a>
                                <!-- <span> | Bookmark this News</span>
                                <a class="bookmark" target="_blank" data-original-title="Bookmark" href="#" data-toggle="tooltip" data-placement="top"><i class="fa fa-bookmark"></i></a> -->
                            <!--<a class="bookmarked default-color" target="_blank" data-original-title="UnBookmark" href="#" data-toggle="tooltip" data-placement="top"><i class="fa fa-bookmark"></i></a>-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            

        </div>
    </div>
</div>
﻿<section class="find-job cyber section inner-articles">

<div class="container">

<h2 class="section-title">السيبرانية التشهير</h2>

<div class="dotted-border">

<div class="dotted-line"></div>

<div class="dotted-line"></div>

<div class="dotted-line"></div>

</div>

<div class="row">

<div class="col-md-9">

<div id="">		

					

<p>بالعدل يعترف خطورة تشهير الإلكترونية. عموما،
التشهير عبارة عن بيان زائف وغير منقطع عن الحقائق ضار بسمعة شخص ما ،
ونشرت "مع الخطأ" ، وهذا يعني نتيجة للإهمال أو الخبث. عناصر الإنترنت
المطالبة بالتشهير هي في الأساس مطالبة التشهير التقليدية وتشمل عادةً ما يلي:
إفادة كاذبة وتشهيرية بشأن شخص آخر ؛ منشور غير منقطع النظير إلى الثلث
حفل؛ خطأ يصل إلى حد الإهمال من جانب الناشر ؛ وإما قابلية التنفيذ
من البيان بغض النظر عن الضرر الخاص أو وجود ضرر خاص بسبب
نشر. لمزيد من المعلومات حول التشهير الإلكتروني ، يرجى التحقق من الاتصال و
رابط تنظيم لجنة تكنولوجيا المعلومات:

 <a href="http://www.citc.gov.sa/en/RulesandSystems/CITCSystem/Pages/CybercrimesAct.aspx" target="_blank" style="color:#b86c21"> http://www.citc.gov.sa/en/RulesandSystems/CITCSystem/Pages/CybercrimesAct.aspx. </a> </p>



<!--<blockquote>-->
    <p>تقع على عاتق الفرد مسؤولية احترام الأفراد الآخرين والتأكد دائمًا من أن المحتويات المنشورة على جميع وسائل التواصل الاجتماعي هي:</p>
<!--</blockquote>-->
<!--<hr class="dark-grey" />-->
<!--<h3>The following are the Mediums by which Cyber Defamtion can be Happen</h3>-->
<ol>
   <li>مجموعة واتس اب</li>
   <li>تغريد</li>
   <li>إينستاجرام, إلخ</li>
</ol>
<p>لا يسبب أي ضرر لأشخاص آخرين بالإضافة إلى منع انتشار أخبار كاذبة مما قد يؤدي إلى نتائج غير سارة</p>

</div>
</div>


</div>
</div>
</section>

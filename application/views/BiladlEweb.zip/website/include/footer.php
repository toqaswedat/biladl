 <!-- Footer Section Start -->
      <footer>
<section class="footer-Content">
<div class="container">
<div class="row">
<div class="col-md-5 col-sm-5 col-xs-12">
<div class="widget">
<h3 class="block-title text-center">Quick Links</h3>
<ul class="menu text-center">
<li><a href="<?=base_url('Pages/about_us');?>">About Us</a></li>
<li><a href="<?=base_url('Pages/terms');?>">Terms & Conditions</a></li>
<li><a href="<?=base_url('Pages/privacy_policy');?>">Privacy Policy</a></li>
<li><a href="<?=base_url('Pages/contact_us');?>">Contact</a></li>
</ul>
</div>
</div>
<div class="col-md-2 col-sm-2 col-xs-12">
    <div class="widget">
     <h3 class="block-title"><img src="<?=base_url();?>assets/website/img/logo.png" class="img-responsive" alt="Footer Logo"></h3>
    </div>
</div>
<div class="col-md-5 col-sm-5 col-xs-12 text-center">
<div class="widget">
<h3 class="block-title text-center">Follow Us</h3>
<div class="bottom-social-icons social-icon">
<a class="twitter" href="#"><i class="ti-twitter-alt"></i></a>
<a class="facebook" href="#"><i class="ti-facebook"></i></a>
<a class="youtube" href="#"><i class="ti-youtube"></i></a>
<a class="dribble" href="#"><i class="ti-dribbble"></i></a>
<a class="linkedin" href="#"><i class="ti-linkedin"></i></a>
</div>
</div>
</div>
</div>
</div>
</section>


<div id="copyright">
<div class="container">
<div class="row">
<div class="col-md-12">
<div class="site-info text-center">
<p>All Rights reserved &copy; 2017 - Designed & Developed by <a rel="nofollow" target="_blank" href="http://iprismtech.com">iPrism Technoloiges</a></p>
</div>
</div>
</div>
</div>
<hr />
<div class="container">
<div class="row">
<div class="site-info disclaimer text-center">
<p><strong>Disclaimer : </strong>Lorem ipsum dolor sit amet, sit essent maluisset temporibus an, ad usu habeo vidisse consetetur. Nam scripta appareat cu. Vis no magna falli vitae, pro rationibus mnesarchum eloquentiam ad, probo oblique propriae duo in. Ne mel solum delenit, sea cu sale semper, te duo expetendis scripserit dissentiet. Te veri adipiscing his, quem ullum debet has eu, no duo postulant referrentur. Quo consetetur voluptatum assueverit cu, eum ne mutat lorem definitionem.Lorem ipsum dolor sit amet, sit essent maluisset temporibus an, ad usu habeo vidisse consetetur. Nam scripta appareat cu. Vis no magna falli vitae, pro rationibus mnesarchum eloquentiam ad, probo oblique propriae duo in. Ne mel solum delenit, sea cu sale semper, te duo expetendis scripserit dissentiet. Te veri adipiscing his, quem ullum debet has eu, no duo postulant referrentur. Quo consetetur voluptatum assueverit cu, eum ne mutat lorem definitionem.</p>
</div>
</div>
</div>
</div>

</footer>
      <!-- Footer Section End -->  
      
      <!-- Go To Top Link -->
      <a href="#" class="back-to-top">
        <i class="ti-arrow-up"></i>
      </a>
        
      <div id="loading">
        <div id="loading-center">
          <div id="loading-center-absolute">
            <div class="object" id="object_one"></div>
            <div class="object" id="object_two"></div>
            <div class="object" id="object_three"></div>
            <div class="object" id="object_four"></div>
            <div class="object" id="object_five"></div>
            <div class="object" id="object_six"></div>
            <div class="object" id="object_seven"></div>
            <div class="object" id="object_eight"></div>
          </div>
        </div>
      </div>
        
    <!-- Main JS  -->         
    <script type="text/javascript" src="<?=base_url();?>assets/website/js/bootstrap.min.js"></script>    
    <script type="text/javascript" src="<?=base_url();?>assets/website/js/material.min.js"></script>
    <script type="text/javascript" src="<?=base_url();?>assets/website/js/material-kit.js"></script>
    <script type="text/javascript" src="<?=base_url();?>assets/website/js/jquery.parallax.js"></script>
    <script type="text/javascript" src="<?=base_url();?>assets/website/js/owl.carousel.min.js"></script>
    <script type="text/javascript" src="<?=base_url();?>assets/website/js/jquery.slicknav.js"></script>
    <script type="text/javascript" src="<?=base_url();?>assets/website/js/main.js"></script>
    <script type="text/javascript" src="<?=base_url();?>assets/website/js/jquery.counterup.min.js"></script>
    <script type="text/javascript" src="<?=base_url();?>assets/website/js/waypoints.min.js"></script>
    <script type="text/javascript" src="<?=base_url();?>assets/website/js/jasny-bootstrap.min.js"></script>
    <script type="text/javascript" src="<?=base_url();?>assets/website/js/bootstrap-select.min.js"></script>
    <script type="text/javascript" src="<?=base_url();?>assets/website/js/form-validator.min.js"></script>
    <script type="text/javascript" src="<?=base_url();?>assets/website/js/contact-form-script.js"></script>    
    <script type="text/javascript" src="<?=base_url();?>assets/website/js/jquery.themepunch.revolution.min.js"></script>
    <script type="text/javascript" src="<?=base_url();?>assets/website/js/jquery.themepunch.tools.min.js"></script>
     <script type="text/javascript" src="<?=base_url();?>assets/website/js/pagenationTPS.js"></script>
     <audio id="audio-alert" src="<?=base_url();?>assets/audio/alert.mp3" preload="auto"></audio>
<audio id="audio-fail" src="<?=base_url();?>assets/audio/fail.mp3" preload="auto"></audio>
  </body>
</html>
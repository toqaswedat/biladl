﻿        <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12">
            <!-- Simple post content example. -->
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="pull-left">
                        <a href="#">
                            <!-- <img class="media-object img-circle" src="https://lut.im/7JCpw12uUT/mY0Mb78SvSIcjvkf.png" width="50px" height="50px" style="margin-right:8px; margin-top:-5px;"> -->
                        </a>
                    </div>
                    <h4><a href="#" style="text-decoration:none;"><strong>Contact Us</strong></a></h4>
                    <div class="post-content">
                        <div class="col-sm-12">
						<div class="post-content">
                          <!--       <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, eiusmod tempor incididunt ut labore. Lorem ipsum dolor sit amet, consectetur adipiscing elit, eiusmod tempor incididunt ut labore et dolore magna aliqua. Class aptent taciti sociosqu ad litora torquent…</p>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Error aliquam facere aliquid atque accusamus nostrum mollitia beatae quasi vel dolorem, autem nisi! Eius facere magni culpa commodi voluptatem, ducimus dolorum. consectetur adipisicing elit. Hic repellat rerum cupiditate unde iure fuga quisquam voluptas quae voluptatum, perferendis eum, doloremque.</p> -->
                                <hr />
                                <div class="row contact">
                                    <!-- <div class="col-lg-6">
                                        <blockquote>
                                            <span class="quote-text">
                                            Call us On :
                                            </span><hr />
                                            <h2>+91-9999 999 999</h2>
                                        </blockquote>
                                    </div> -->
                                    <div class="col-lg-6">
                                        <blockquote>
                                            <span class="quote-text">
                                            Mail us :
                                            </span><hr />
                                            <h2>info@biladil.com</h2>
                                        </blockquote>
                                        </div>
                                </div>
                                <!-- <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Error porro ipsam non rerum, itaque nihil aliquid libero inventore. Eius architecto placeat quis nam similique, nobis quod, animi amet. Minima, laboriosam! possimus minus nisi iure pariatur exercitationem blanditiis nesciunt sequi! Nisi, neque, laborum voluptatem exercitationem minus facere reiciendis quis.</p> -->
                            </div>
					</div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    </div>
</div>
</div>
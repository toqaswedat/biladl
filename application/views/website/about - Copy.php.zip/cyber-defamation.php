<section class="find-job cyber section inner-articles">
<div class="container">
<h2 class="section-title">Cyber Defamation</h2>
<div class="dotted-border">
<div class="dotted-line"></div>
<div class="dotted-line"></div>
<div class="dotted-line"></div>
</div>
<div class="row">
<div class="col-md-9">
<div id="">		
					
<p>Biladl acknowledges the seriousness of Cyber Defamation. Generally,
defamation is a false and unprivileged statement of fact that is harmful to someone's reputation,
and published "with fault," meaning as a result of negligence or malice. The elements of a cyber-
defamation claim are essentially the same as a traditional defamation claim and typically include:
a false and defamatory statement concerning another; an unprivileged publication to a third
party; fault amounting at least to negligence on the part of the publisher; and either actionability
of the statement irrespective of special harm or the existence of special harm caused by the
publication. For further information about cyber defamation, please check Communication and
information technology commission regulation link:

<a href="http://www.citc.gov.sa/en/RulesandSystems/CITCSystem/Pages/CybercrimesAct.aspx" target="_blank" style="color:#b86c21"> http://www.citc.gov.sa/en/RulesandSystems/CITCSystem/Pages/CybercrimesAct.aspx. </a>
</p>
<br />
<!--<blockquote>-->
    <p>It is the individual responsibilty to respect other individuals and always ensure that the contents posted on All social Media namely</p>
<!--</blockquote>-->
<!--<hr class="dark-grey" />-->
<!--<h3>The following are the Mediums by which Cyber Defamtion can be Happen</h3>-->
<ol>
   <li>Watsapp groups</li>
   <li>Twitter</li>
   <li>Instagram, Etc</li>
</ol>
<p>Does not cause any harm to other people in addition to preventing the spread of false news which might leads to unpleasent outcomes</p>

</div>
</div>


</div>
</div>
</section>

 <!-- Page Header Start -->
      <div class="page-header" style="background: url(<?=base_url('assets/website/img/banner1.jpg');?>);">
        <div class="container">
          <div class="row">         
            <div class="col-md-12">
              <div class="breadcrumb-wrapper">
                <h2 class="product-title">About Us</h2>
                <ol class="breadcrumb">
                  <li><a href="#"><i class="ti-home"></i> Home</a></li>
                  <li class="current">About Us</li>
                </ol>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- Page Header End -->        

      <!-- Main container Start -->  
      <div class="about section">
        <div class="container content">
          <div class="row">          
            <div class="col-md-6 col-sm-12">
              <img src="<?=base_url();?>assets/website/img/about/img1.jpg" alt="">              
            </div>
            <div class="col-md-6 col-sm-12">
              <div class="about-content">
                <p>BILADL consists of a Saudi-based group of eminent experienced lawyers whose job is to provide
lawyers and legal advice to every single all the citizens and residents of thein Kingdom of Saudi
Arabia at nominal rates for membership. </p>
<p>We are teaming up with major law firms and with individuals who have expertise in every field of law to give you the best service available, at a price you can afford.</p>

<p>At Biladl our commitment is to give you the best legal advice when and where you need it.
</p>

               <!-- <a href="#" class="btn btn-common">Learn More</a>-->
               <blockquote><b>Problem REMAIN Problems UNTIL YOU GET CONNECTED TO Biladl</b></blockquote>
               <p>Biladl have teamed with many a leading law firms in every country whilst working exclusively with one of the most prestigious and community orientated and committed law firm in different countries </p>
               <p>Our Flagship Offices In the Middle East is centered In jeddah KSA with Representatives in Riyadh and Mediina and plans to Collaborate with Biladl Legal Representatives in Every city and country in the World  </p>

              </div>
            </div>
            <div class="col-md-12">
             <p>We are constantly seeking partnerships with legal firms that can serve our clients better and therefore We invite members of legal fraternity to Get in touch.  </p>
<p>Biladl serves private individuals primarily providing a broad range of proper legal issues , support and legal advisory services via the Online Portal as well as  Legal Representatives in our on Call center</p>
<p>We follow a client-orientated management philosophy where our subscriber clients come first and we constantly re-evaluate how we can best serve them. This philosophy underpins our core values:</p>
<div class="row"><br>
 

 <div class="innovation">

  <div class="col-md-1">
  </div>
  <div class="col-md-2">
    <h4><i class="fa fa-heart-o" aria-hidden="true"></i> Biladl Care</h4>
    <p>We care for our subscribers , our legalAdvisory team and our communities as happy families foster Peace </p>
  </div>
  <div class="col-md-2">
    <h4><i class="fa fa-ravelry" aria-hidden="true"></i> Innovation</h4>
    <p>Biladl aims to provide you our Subscriber the most innovative easy and effective service to ensure Peace of Mind </p>
  </div>
  <div class="col-md-2">
    <h4><i class="fa fa-hand-peace-o" aria-hidden="true"></i> Standards</h4>
    <p>We set standards and aim to meet them daily<br> 

Your Peace&Pleasure is our Measure of Standards </p>
  </div>
  <div class="col-md-2">
    <h4><i class="fa fa-bullseye" aria-hidden="true"></i> Expertise</h4>
    <p>Our experts aim is to simplify your Life and Foster Peace in all your daily interactions </p>
  </div>
  <div class="col-md-2">
    <h4><i class="fa fa-snowflake-o" aria-hidden="true"></i> Diversity</h4>
    <p>Our Home is Open to All subscribers and our Differences make us stronger to Achieve Peaceful Solutions </p>
  </div>
  <div class="col-md-1">
  </div>
  <div class="clearfix"></div>

</div>
<div class="clearfix"></div>
<div class="row">
  <div class="col-md-6">
<p>We have on board a new breed of legal Advisors and embrace humane values to set us apart as We lead by setting the standard so others follow. </p><br>

<p>Biladl is being built on our willingness to explore new and unconventional approaches to law and the practice of law, and our clients will expect a different approach and unique solutions to ensure Peace of Mind </p>
</div>
  <div class="col-md-6">
<p>Our diversity defines who we are and makes all the difference to our clients. We aim to be the law firm which has noBorders  from within South Africa to The Middle East Then incorporating the eastern and western people so we set the standard for transformation in the legal industry, ensuring that we have a transformed and diverse legal team with a broad perspective to serve and understand our clients.</p>
</div>

  </div>
<br><br>
<blockquote>We are passionate about law and our clients and love what we do!</blockquote>


<br>
      
            </div>
          </div>
        </div>
      </div>
    </div>
      <!-- Main container End -->  
 
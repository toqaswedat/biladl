<!-- Page Header Start -->
      <div class="page-header" style="background: url(<?=base_url('assets/website/img/banner1.jpg');?>);">
        <div class="container">
          <div class="row">         
            <div class="col-md-12">
              <div class="breadcrumb-wrapper">
                <h2 class="product-title">About Us</h2>
                <ol class="breadcrumb">
                  <li><a href="#"><i class="ti-home"></i> Home</a></li>
                  <li class="current">About Us</li>
                </ol>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- Page Header End -->        

      <!-- Main container Start -->  
      <div class="about section">
        <div class="container">
          <div class="row">          
            <div class="col-md-6 col-sm-12">
              <img src="<?=base_url();?>assets/website/img/about/img1.jpg" alt="">              
            </div>
            <div class="col-md-6 col-sm-12">
              <div class="about-content">
                <p>BILADL consists of a Saudi-based group of eminent experienced lawyers whose job is to provide lawyers and legal advice to every single citizen and resident in Kingdom of Saudi Arabia at nominal rates for membership.
</p>
               <!-- <a href="#" class="btn btn-common">Learn More</a>-->
               <blockquote>Problem REMAIN Problems UNTIL YOU GET CONNECTED TO Biladl</blockquote>
               <p>BILADL will assist you in all legal issues depending on your service plans such as labour issues, personal disputes, marital issues, traffic violations, rental disputes etc. Our aim is to offer guaranteed legal services by well trained and highly skilled team of lawyers to our members facing any aforementioned problem in the light of our service plans. </p>
               <p>Due to lack of knowledge about one’s legal rights, handling and tackling such issues legally becomes a big challenge. Everyone can’t afford to acquire legal services both in terms of their valuable time and hard-earned money.</p>
              </div>
            </div>
            <div class="col-md-12">
             
<p>Considering the fact that the Kingdom of Saudi Arabia is a second home to many expatriates, our service is a must-have for every individual expatriate as well as Saudi national. Every member subscribed to our offered plans will have their own lawyer to take care of their issues.</p>
<p>To start with, our focus will be mainly on labour issues, personal disputes, marital issues and rental disputes. Our aim is to open door for every member who has any problem in the above-mentioned focus areas.</p>
<p class="text-center">Problems remain problems until you get connected to BILADL.</p>
 <hr />
       <div class="col-md-6 col-sm-12">
          <blockquote class="blockquote-blue shadow b-r-30 our-vision col-centered">
            <h3>Our Vision</h3>
            <p>Instant and affordable membership for reliable and satisfactory legal assistance to all expatriates as well as Saudi nationals 24/7/365 irrespective of their societal and financial status.</p>
          </blockquote>
        </div>
        <div class="col-md-6 col-sm-12">
          <blockquote class="blockquote-blue shadow b-r-30 our-vision col-centered">
             <h3>Our Mission</h3>
             <p>Provide dynamic legal assistance for all problems to all our valued members. <br /><br /></p>
          </blockquote>
        </div>
            </div>
          </div>
        </div>
      </div>
      <!-- Main container End -->  
      
      <!-- Service  Section -->
      <section id="service-main" class="section content">
        <!-- Container Starts -->
        <div class="container">
       
          <div class="row">    
          <h2>Product Overview</h2>
         <hr />
         <blockquote class="blockquote-blue">
         BILADL provides legal counselling and legal representation for you and your family including your spouse, partner or children under the age of 18. Protect your family’s legal rights with our Gold, GoldPLUS or Platinum Membership options. <br />

         </blockquote>
              <h3>You get:</h3>
            <div class="col-sm-6 col-md-4">
              <div class="service-item">
                <div class="icon-wrapper">
                 <i class="fa fa-users" aria-hidden="true"></i>
                </div>
                <p>
                  Face-to-face legal counselling and legal assistance with BILADL’s legal counsellors countrywide
                </p>
              </div>
              <!-- Service-Block-1 Item Ends -->
            </div>

            <div class="col-sm-6 col-md-4">
              <!-- Service-Block-1 Item Starts -->
              <div class="service-item">
                <div class="icon-wrapper">
                  <i class="fa fa-clock-o" aria-hidden="true"></i>
                </div>
                <p>
                  24-hour legal assistance via our dedicated legal lines
                </p>
              </div>             
            </div>

            <div class="col-sm-6 col-md-4">
              <div class="service-item">
                <div class="icon-wrapper">
                  <i class="fa fa-user" aria-hidden="true"></i>
                </div>
                <p>
                   Access to our network of BILADLs who will assist you
                </p>
              </div>
            </div>
          </div>

          <div class="row">    
          <h3>How BILADL works?</h3>

          <ul class="bil-list">
          <li>Members have constant access to our in-house BILADLs, who offer online email-based legal assistance during office hours and face-to-face legal assistance when required.</li>
          <li>Our BILADL have extensive experience and training. They are able to advise you, write letters on your behalf and attempt to resolve legal issues without going to court.</li>
          <li>Our BILADL will refer you to an attorney when you have a legal problem that requires a court hearing or representation to an Alternative Dispute Resolution Forum.</li>
          <li>Our legal line offers telephonic legal assistance 24 hours a day, 7 days a week, 365 days a year.</li>
          </ul>

<h3>What you get at BILADL:</h3>
<p>Examples of matters that BILADL will assist you with:</p>
<ul class="bil-list">
    <li>Insurance problems (e.g. life policy or car insurance claims)</li>
    <li>Consumer-related problems (e.g. guarantees and defective goods)</li>
    <li>Home-owner problems (e.g. faulty alterations, home improvements, defective building works)</li>
    <li>Job-related matters (e.g. unfair dismissals, unfair retrenchments)</li>
    <li>Criminal charges against a Member or his/her family</li>
    <li>Motor vehicle problems or accident claims</li>
    <li>Personal injury claims</li>
</ul>

<h3>What is NOT covered by BILADL?</h3>
<p>Our policies are kept affordable by not covering:</p>
 <ul class="bil-list">
          <li>Matrimonial disputes (e.g. contested divorces)</li>
<li>Defamation cases</li>
<li>Business related matters</li>
<li>Admission of guilt fines</li>
<li>Cover for legal matters that arose before you joined BILADL or during your 3-month waiting period**</li>
<li>Collective actions</li>
<li>Traffic fines</li>
<li>Political matters</li>
<li>Child maintenance</li>
</ul>

<h3>BILADL Membership includes:</h3>
<ul class="bil-list">
    <li>BILADL provides legal counselling and assistance and covers legal fee* per case for criminal, civil and labour related matters</li>
    <li>Legal advice</li>
    <li>Counselling on court procedures</li>
    <li>Negotiations and correspondence with third parties on your behalf</li>
    <li>Assistance and counselling regarding basic legal documents, such as legal contracts</li>
    <li>Debt relief, like settlement negotiations, consolidations, payment extensions, blacklisting assistance or even bankruptcy</li>
</ul>

<p>**Terms and conditions apply</p>



<p class="desc">
Through our extended benefits, BILADL strives to assist with any legal matters – even if they are not covered by your BILADL policy, such as:</p>

<ul class="bil-list">
<li>Debt services (e.g. settlement negotiations, debt counselling, rescission of administration orders and judgments)</li>
<li>Family Services (e.g. unopposed divorces, child maintenance matters, drafting of basic wills)</li>
</ul>

<h3>What happens if BILADL refer your matter to an attorney?</h3>
 
<p class="desc">The BILADLs will review and assess your situation. They will also deal with any legal work and following the consultation, if needed, will refer you to our network of attorneys. BILADL will then cover any the legal fee* that may arise. In such cases:</p>
<ul class="bil-list">
<li>The attorney will lodge a claim with BILADL and request confirmation that the matter be covered by your membership</li>
<li>On approval, the attorney will proceed with your matter</li>
</ul>
<div class="row">
<div class="col-lg-6">
<blockquote>
<h4>24-hour Legal Assistance </h4>
<p class="desc">We offer telephonic legal counselling and assistance such as bail application, 24 hours a day, 7 days a week, 365 days a year.</p>
</blockquote>
</div>
<div class="col-lg-6">
<blockquote>
<h4>3-Month Waiting Period</h4>
<p class="desc">You have a 3-month waiting period from the date of your first premium payment before BILADL will pay for legal expenses and we will only cover legal matters that arose after the 3-month waiting period. However, you get immediate access to our in-house BILADLs and 24-hour legal line.</p>
</blockquote>
</div>
</div>

          </div>
        </div>
      </section>
      <!-- Service Main Section Ends -->
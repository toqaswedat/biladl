﻿
      <!-- Footer Section Start -->
     

<footer>

<section class="footer-Content">
<div class="container">
<div class="row">
<div class="col-md-5 col-sm-5 col-xs-12">
<div class="widget">
<h3 class="block-title text-center">ارتباطات سريعة</h3>
<ul class="menu text-center">
<li><a href="#">عن الموقع</a></li>
<li><a href="#">الشروط والأحكام</a></li>
<li><a href="#">سياسة الخصوصية</a></li>
<li><a href="#">الاتصال بنا</a></li>
</ul>
</div>
</div>
 <div class="col-md-2 col-sm-2 col-xs-12">
                <div class="widget">
                 <h3 class="block-title"><img  src="<?=base_url('assets/website/arbic/');?>img/logo.png" class="img-responsive" alt="Footer Logo"></h3>
                 
                </div>
              </div>
<div class="col-md-5 col-sm-5 col-xs-12 text-center">
<div class="widget">
<h3 class="block-title text-center">اتبع بنا</h3>
<div class="bottom-social-icons social-icon">
<a class="twitter" href="#"><i class="ti-twitter-alt"></i></a>
<a class="facebook" href="#"><i class="ti-facebook"></i></a>
<a class="youtube" href="#"><i class="ti-youtube"></i></a>
<a class="dribble" href="#"><i class="ti-dribbble"></i></a>
<a class="linkedin" href="#"><i class="ti-linkedin"></i></a>
</div>
<!--<p>Join our mailing list to stay up to date and get notices about our new releases!</p>
<form class="subscribe-box">
<input type="text" placeholder="Your email">
<input type="submit" class="btn-system" value="Send">
</form>-->
</div>
</div>
</div>
</div>
</section>


<div id="copyright">
<div class="container">
<div class="row">
<div class="col-md-12">
<div class="site-info text-center">
<p>All Rights reserved &copy; 2017 - Designed & Developed by <a rel="nofollow" target="_blank" href="http://iprismtech.com">iPrism Technoloiges</a></p>
</div>
</div>
</div>
</div>
<hr />
<div class="container">
<div class="row">
<div class="site-info disclaimer text-center">
<p><strong>Disclaimer : </strong>Lorem ipsum dolor sit amet, sit essent maluisset temporibus an, ad usu habeo vidisse consetetur. Nam scripta appareat cu. Vis no magna falli vitae, pro rationibus mnesarchum eloquentiam ad, probo oblique propriae duo in. Ne mel solum delenit, sea cu sale semper, te duo expetendis scripserit dissentiet. Te veri adipiscing his, quem ullum debet has eu, no duo postulant referrentur. Quo consetetur voluptatum assueverit cu, eum ne mutat lorem definitionem.Lorem ipsum dolor sit amet, sit essent maluisset temporibus an, ad usu habeo vidisse consetetur. Nam scripta appareat cu. Vis no magna falli vitae, pro rationibus mnesarchum eloquentiam ad, probo oblique propriae duo in. Ne mel solum delenit, sea cu sale semper, te duo expetendis scripserit dissentiet. Te veri adipiscing his, quem ullum debet has eu, no duo postulant referrentur. Quo consetetur voluptatum assueverit cu, eum ne mutat lorem definitionem.</p>
</div>
</div>
</div>
</div>

</footer>



<!-- Modal Online Advice -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Online Advice</h4>
        <p>Submit Your Query & Get an Immediate Response</p>
      </div>
      <div class="modal-body">
        <div class="page-login-form">
<form role="form" class="login-form">
<div class="form-group">
<div class="input-icon">
<i class="ti-pencil-alt"></i>
<!--<input type="text" id="sender-email" class="form-control" name="email" placeholder="Email">-->
<textarea class="form-control" placeholder="Your Query..."></textarea>
</div>
</div>
<div class="form-group">
<div class="input-icon">
<i class="ti-info"></i>
<input type="text" class="form-control" placeholder="Appropirate Heading">
</div>
</div>

<div class="form-group">
<div class="input-icon">
<div class="row">
<div class="col-sm-6 col-xs-12">
<label for="sel1">Choose Topic</label>
  <select class="form-control" id="sel1">
    <option></option>
    <option>Lorem ipsum dolor sit amet</option>
    <option>Lorem ipsum dolor sit amet</option>
    <option>Lorem ipsum dolor sit amet</option>
    <option>Lorem ipsum dolor sit amet  </option>
  </select>
</div>

<div class="col-sm-6 col-xs-12">
<label for="sel1">Choose City</label>
  <select class="form-control" id="Select1">
    <option></option>
    <option>Hyderbad</option>
    <option>Mumbai</option>
    <option>Banglore</option>
    <option>Chennai</option>
    <option>Panjab</option>
    <option>Sikkim</option>
    <option>Kashmir</option>
    <option>Manipal</option>
    <option>Aurangabad</option>
    <option>Nasik</option>
    <option>Faridabad</option>
  </select>
</div>
</div>
</div>
</div>

<div class="form-group">
 <label for="sel1">Attach Document if any</label>
<div class="input-group">
  
    <input type="text" class="form-control" id="upload-file-info" readonly>
     <label class="input-group-btn">
        <span class="btn btn-file">
           <i class="ti-clip"></i> Browse&hellip; <input id="my-file-selector" type="file" style="display:none;" onchange="$('#upload-file-info').val($(this).val());">
        </span>
    </label>
</div>
</div>

<div class="form-group">
<div class="input-icon">
<div class="row">
<div class="col-sm-6 col-xs-12">
<div class="input-icon">
<i class="ti-email"></i>
<input type="text" class="form-control" placeholder="Email ID">
</div>
</div>
<div class="col-sm-6 col-xs-12">
<div class="input-icon">
<i class="ti-mobile"></i>
<input type="text" class="form-control" placeholder="Mobile No">
</div>
</div>
</div>
</div>
</div>
<hr />
<div class="col-lg-6 center-div"><button class="btn btn-common log-btn">Submit Query</button></div>

</form>
</div>
      </div>
    </div>

  </div>
</div>


<div id="call-center" class="modal no-bg fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
    
      <div class="modal-body">
      <button type="button" class="close" data-dismiss="modal">&times;</button>
      <h2 class="call-heading"> 1800-000-000</h2>
          <img class="call-img"  href="<?=base_url('assets/website/arbic/');?>img/home/call-us.png" />
      </div>
    </div>

  </div>
</div>

<!-- Modal Online Advice -->
<div id="legal-advice" class="modal fade" role="dialog">
  <div class="modal-dialog medium-modal">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Legal Advice</h4>
       <!-- <p>Submit Your Query & Get an Immediate Response</p>-->
      </div>
      <div class="modal-body">
       <ul class="legal-points">
       <li><a href="news.html">Legal News <i class="ti-angle-right"></i></a></li>
       <li><a href="useful-links.html">Usefull Links <i class="ti-angle-right"></i></a></li>
       <li><a href="documents.html">Documents <i class="ti-angle-right"></i></a></li>
       </ul>
      </div>
    </div>

  </div>
</div>

<!-- Modal Online Advice -->
<div id="legal-help" class="modal fade" role="dialog">
  <div class="modal-dialog medium-modal">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Legal Help</h4>
       <!-- <p>Submit Your Query & Get an Immediate Response</p>-->
      </div>
      <div class="modal-body">
       <ul class="legal-points">
       <li><a href="articles.html">Articles <i class="ti-angle-right"></i></a></li>
       <li><a href="faq.html">FAQ's <i class="ti-angle-right"></i></a></li>
       <li><a href="online-advice.html">Advice <i class="ti-angle-right"></i></a></li>
       </ul>
      </div>
    </div>

  </div>
</div>





<a href="#" class="back-to-top">
<i class="ti-arrow-up"></i>
</a>
<div id="loading">
<div id="loading-center">
<div id="loading-center-absolute">
<div class="object" id="object_one"></div>
<div class="object" id="object_two"></div>
<div class="object" id="object_three"></div>
<div class="object" id="object_four"></div>
<div class="object" id="object_five"></div>
<div class="object" id="object_six"></div>
<div class="object" id="object_seven"></div>
<div class="object" id="object_eight"></div>
</div>
</div>
</div>

<script type="text/javascript"  src="<?=base_url('assets/website/arbic/');?>js/jquery-min.js"></script>
<script type="text/javascript"  src="<?=base_url('assets/website/arbic/');?>js/bootstrap.min.js"></script>
<script src="<?=base_url('assets/website/js/bootstrap.min.js');?>"></script>

<script type="text/javascript"  src="<?=base_url('assets/website/arbic/');?>js/material.min.js"></script>
<script type="text/javascript"  src="<?=base_url('assets/website/arbic/');?>js/material-kit.js"></script>
<!--<script type="text/javascript"  src="<?=base_url('assets/website/arbic/');?>js/color-switcher.js"></script>-->
<script type="text/javascript"  src="<?=base_url('assets/website/arbic/');?>js/jquery.parallax.js"></script>
<script type="text/javascript"  src="<?=base_url('assets/website/arbic/');?>js/owl.carousel.min.js"></script>
<script type="text/javascript"  src="<?=base_url('assets/website/arbic/');?>js/jquery.slicknav.js"></script>
<script type="text/javascript"  src="<?=base_url('assets/website/arbic/');?>js/main.js"></script>
<script type="text/javascript"  src="<?=base_url('assets/website/arbic/');?>js/jquery.counterup.min.js"></script>
<script type="text/javascript"  src="<?=base_url('assets/website/arbic/');?>js/waypoints.min.js"></script>
<script type="text/javascript"  src="<?=base_url('assets/website/arbic/');?>js/jasny-bootstrap.min.js"></script>
<script type="text/javascript"  src="<?=base_url('assets/website/arbic/');?>js/bootstrap-select.min.js"></script>
<script type="text/javascript"  src="<?=base_url('assets/website/arbic/');?>js/form-validator.min.js"></script>
<script type="text/javascript"  src="<?=base_url('assets/website/arbic/');?>js/contact-form-script.js"></script>
<!--  <script  href="<?=base_url('assets/website/arbic/');?>plugins/slick/slick.js" type="text/javascript"></script>
    <script  href="<?=base_url('assets/website/arbic/');?>plugins/slick/slick-custom.js" type="text/javascript"></script>-->
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <script  src="<?=base_url('assets/website/arbic/');?>plugins/light-slider/src/js/lightslider.js" type="text/javascript"></script>
    <script>
        $(window).resize(function () {
            $(function () {
                $("#addClass").click(function () {
                    $('#qnimate').addClass('popup-box-on');
                });

                $("#removeClass").click(function () {
                    $('#qnimate').removeClass('popup-box-on');
                });
            })

                    
            $('.search-box').hide();
            $('.search-button').click(function () {
                $('.search-box').toggle("slide");
            });
            $('.close-search').click(function () {
                $('.search-box').toggle("slide");
            });

            if ($(window).width() <= 1024) {
                //$('.navbar .nav').addClass('wpb-mobile-menu');
                //$('.navbar .nav').removeClass('nav navbar-nav navbar-right float-right');
                //alert();
                // if larger or equal
                // $('.main-category-list ul').attr('id', 'category-slider');
                // $('.category-section-home ul').attr('class', 'sub-category-slider');
                //                $('.navbar .nav').addClass('wpb-mobile-menu');
                //                $('.navbar .nav').removeClass('nav navbar-nav navbar-right float-right');
            } else {
                // if smaller
                // $('.main-category-list ul').removeAttr('id', 'category-slider');
                // $('.main-category-list ul').attr('id', 'category-mobile-slider');
            }
        }).resize();


        $(document).ready(function() {
      $("#content-slider").lightSlider({
            item:1,
                loop:true,
        addClass: 'center-thumbs',
                rtl:true,
                keyPress:true,
        autoWidth: false,
        slideMove: 1, // slidemove will be 1 if loop is true
        slideMargin: 10,
    centerMode: true,
        responsive : [],
            });

            $(".main-slider-ul").lightSlider({
            item:1,
                loop:true,
                rtl:true,
                keyPress:true,
        autoWidth: false,
        slideMove: 1, // slidemove will be 1 if loop is true
        slideMargin: 10,
        responsive : [],
            });

            $(".testimonial-slider").lightSlider({
            item:1,
                loop:true,
                rtl:true,
                keyPress:true,
        autoWidth: false,
        slideMove: 1, // slidemove will be 1 if loop is true
        slideMargin: 10,
        responsive : [],
            });

             $(".article-slider").lightSlider({
            rtl:true,
            item:3,
                loop:true,
                rtl:true,
                keyPress:true,
        autoWidth: false,
        slideMove: 1, // slidemove will be 1 if loop is true
        slideMargin: 10,
        responsive : [
        
         {
                  breakpoint: 1200,
                  settings: {
                    item: 3,
                    slideMove: 1
                  }
                },

                {
                  breakpoint: 600,
                  settings: {
                    item: 1,
                    slideMove: 1
                  }
                }
        ],
            });
            $('#image-gallery').lightSlider({
                gallery:true,
                item:1,
                thumbItem:9,
                slideMargin: 0,
                speed:500,
                auto:true,
                loop:true,
                onSliderLoad: function() {
                    $('#image-gallery').removeClass('cS-hidden');
                }  
            });
    });
    </script>


</body>
</html>
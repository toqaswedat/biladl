      <!-- Page Header Start -->
      <div class="page-header" style="background: url(<?=base_url();?>assets/website/img/banner4.jpg);">
        <div class="container">
          <div class="row">         
            <div class="col-md-12">
              <div class="breadcrumb-wrapper">
                <h2 class="product-title">Membership Plans</h2>
                <ol class="breadcrumb">
                  <li><a href="<?=base_url();?>"><i class="ti-home"></i> Home</a></li>
                  <li class="current">Membership Plans</li>
                </ol>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- Page Header End -->        

      <!-- Main container Start -->  
      <div class="about section">
        <div class="container">
          <div class="row"> 
            <div class="col-md-12">
                <h4>Your BILADL Membership provides you with many benefits to live life to the fullest with Peace of Mind </h4>
                <p>Membership plans include</p>
                <p>Legal Counseling and Assistance for </p>
                <ul class="bil-list">
                    <li>Civil matters</li>
                    <li>Criminal matters </li>
                    <li>Labour related </li>
                    <li>Family matters </li>
                    <li>Counseling on court procedure </li>
                    <li>Debt relief like settlement negotiations etc</li>
                    <li>Financial advice and Consults</li>
                    <li>Negotiations with third parties in any agreement and contracts </li>
                </ul>
                <br />
                <p>Your Membership gives you the Freedom to live Life Peacefully as Our LegalAdvizors advise and guide you in all your daily legal transaction matters .</p>
                <hr>

                <div class="row">
                <div class="col-md-4">
                    <div class="gray-bg inner-plan">
                <h3>GOLD</h3>
         
                <p><h4 class="m-b-20">SAR 49 per month</h4> This membership plan gives you 24-hour legal assistance via our legal helpline, 7 days a week and 365 days a year, as well as online legal assistance during office hours. </p> 
                <p>Matters that BILADL will assist you with:</p>
                
                <ul class="bil-list">
                    <li>Insurance problems (e.g. car insurance claims)</li>

<li>Consumer related problems (e.g. guarantees and defective goods)</li>

<li>Home-owner problems (e.g. faulty alterations, home improvements, defective building works)</li>

<li>Job related matters (e.g. unfair dismissals, unfair retrenchments)</li>

<li>Criminal charges against our Member or his/her family</li>

<li>Motor vehicle problems and accident claims</li>

<li>Personal injury claims</li>

 <li>Debt services (e.g. settlement negotiations, debt counselling, 



  rescission of administration orders and judgments)</li>


                <h3>Extended benefits:</h3>
                <p class="m-p p-10">BILADL strive to assist with any legal matters you may have, even if  they are not covered by your BILADL membership subject to a consultation where the matter and the fees will be agreed upon. These matters could relate to: </p>
                <ul class="bil-list">
                    <li>Matrimonial disputes (e.g. contested divorces)</li>

<li>Defamation cases</li>

<li>Business related matters</li>

<li>Admission of guilt fines</li>

<li>Cover for legal matters that occurred before your 3 months waiting period*</li>

<li>Collective actions</li>

<li>Traffic fines</li>

<li>Political matters</li>
                </ul>

                <p class="m-p p-10"> Access to our attorneys who will represent you Should your matter need representation in court or Alternative Dispute Resolution Forums such as the Labour Courts etc will always have to be agreed upon </p>
                <p class="m-p p-10">Terms and conditions apply.</p>
               

            </div>
                </div>
                <div class="col-md-4">
                    <div class="gray-bg inner-plan">
                <h3>GOLDPLUS </h3>
        
                <p ><h4 class="m-b-20">SAR 149 per month</h4> gives you</p> 
                <ul class="bil-list">
                    <li>All services and everything else that the Gold Membership offers plus </li>
                    <li>24-hour legal assistance via our legal line, 7 days a week and 365 days a year (e.g., help for urgent with bail application), as well as online legal assistance during office hour</li>
                    <li>Legal Emergency Fast Track - an added legal benefit giving you an immediate ONE hour-consultation per year with a lawyer at no extra charge. You can use it for any matter whether covered by the Membership or not</li>
                </ul>

                <p class="m-p p-10">And </p>
                <ul class="bil-list">
<li>Face-to-face consultation with BILADL</li>




<li>**Access to attorneys who will represent you, should your matter need representation in court or Alternative Dispute Resolution Forums such as Labour Courts etc.</li></li>
 
</ul>


<p class="m-p p-10">*Terms and Conditions apply</p>


            </div>
            </div>
                
                <div class="col-md-4">
                    <div class="gray-bg inner-plan">
                <h3>PLATINUM</h3>
           
                <p ><h4 class="m-b-20">SAR 249 per month</h4></p> 
                <p>PLATINUM Membership will provide you all the benefits of Gold Membership Plus...:</p>
                <ul class="bil-list">
                    <li>All of what the Gold and GoldPlus Membership offers in addition to </li>


<li>Face-to-face consultation with BILADL to answer any of your legal questions.</li>

<li>Access to our attorneys who will represent you. Should your matter need representation in court or Alternative Dispute Resolution Forums such as the Labour Courts etc.</li>

<li>24-hour legal assistance via our legal line, 7 days a week and 365 days a year (e.g. help for urgent bail applications) as well as online legal assistance during office hourss</li>
                </ul>
                <h4>Matters that BILADL will assist you with:</h4>
                <ul class="bil-list">
                    <li>Insurance problems (e.g. car insurance claims)</li>



<li>Consumer related problems (e.g. guarantees and defective goods)</li>



<li>Home-owner problems (e.g. faulty alterations, home improvements, defective building works)</li>



<li>Job related matters (e.g. unfair dismissals, unfair retrenchments)</li>



<li>Criminal charges against our Member or his/her family</li>



<li>Motor vehicle problems and accident claims</li>



<li>Personal injury claims</li>


                </ul>
           
           <h4>Matters that our Legal AdviSers will assist you with:</h4>
           <ul class="bil-list">
                    <li>Matrimonial disputes (e.g. contested divorces)</li>



<li>Defamation cases</li>



<li>Business related matters</li>



<li>Admission of guilt fines</li>



<li>Cover for legal matters that occurred before your 3 months waiting period*</li>



<li>Collective actions</li>



<li>Traffic fines</li>



<li>Political matters</li>



<li>Child maintenance</li>
                </ul>
                <h4>Extended benefits:</h4>
                <p class="m-p p-10">BILADL strive to assist with any legal matters or questions you may have, even if they are not covered by your BILADL policy such as:</p>

                <ul class="bil-list">
                    <li>Debt services (e.g. settlement negotiations, debt counselling, rescission of administration orders and judgments)</li>



<li>Family services (e.g. unopposed divorces, child maintenance matters, drafting of basic wills)</li>



<li>Other civil services (e.g. mediation or referrals to Alternative Dispute Resolution forums such as the CCMA, preparation and referral to Small Claims Court)</li>
            </div>
                
            </div>
        </div>
          </div>
        </div>
      </div>

</div>
      <!-- Main container End -->  
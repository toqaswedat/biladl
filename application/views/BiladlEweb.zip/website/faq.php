<div id="content">
	<div class="container">
		<div class="row">
			<div class="col-md-8 center-div">
				<div class="panel-group" id="accordion">
				<?php $act="in"; foreach ($paged_faqs as $faq_key => $faq_val) : ?>
					<div class="panel panel-default">
						<div class="panel-heading">
							<h4 class="panel-title">
							<a data-toggle="collapse" data-parent="#accordion" href="#co<?=$faq_key;?>">
									<?=$faq_val->title?>
								</a>
							</h4>
						</div>
						<div id="co<?=$faq_key;?>" class="panel-collapse collapse <?=$act;?>">
							<div class="panel-body">
								<p>
									<?=$faq_val->description?>
								</p>								
							</div>
						</div>
					</div>
					<?php $act=""; endforeach; ?>			 	
				</div>
				<div class="clearfix"></div>			
				<?php if($total_pages>1): ?>
				<ul class="pagination  pull-right">
					<li >
						<a href="<?=$prev_url?>" class="btn btn-common"><i class="ti-angle-left"></i> prev</a>
					</li>
					 		<?php  for ($i=1; $i<=$total_pages; $i++) { $class='';
		                                if($C_page==$i){ $class='active'; } ?>
							<li class="<?=$class?>"><a  href="<?=$uri_url;?><?=$i;?>"><?=$i;?></a></li>
							<?php $class=''; } ?>
					
					<li>
						<a href="<?=$next_url?>" class="btn btn-common">	Next <i class="ti-angle-right"></i></a>
					</li>
				</ul>
			  <?php endif; ?>
			</div>
		</div>
	</div>
</div>

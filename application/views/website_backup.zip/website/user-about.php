﻿<div class="col-lg-9 col-md-9 col-sm-12 col-xs-12">
            <!-- Simple post content example. -->
            <div class="panel panel-default">
                <div class="panel-body">
                    <!-- <div class="pull-left">
                        <a href="#">
                            <img class="media-object img-circle" src="https://lut.im/7JCpw12uUT/mY0Mb78SvSIcjvkf.png" width="50px" height="50px" style="margin-right:8px; margin-top:-5px;">
                        </a>
                    </div> -->
                    <h4><a href="#" style="text-decoration:none;"><strong>About Us</strong></a></h4>
                    <div class="post-content">
                        <div class="col-sm-12">
                        <hr />
						<div class="post-content">
                            <p>Biladl the Fully comprehensive Legal portal has teamed with one of the most esteemed and Respected Law firms from Jeddah KSA To Be our flagship Legal Representatives in the MENA Region. Biladl Flagship has qualified trustworthy lawyers graduated from across the world with expertise in every field of law and are always available to ensure all legal situations are addressed to give our members peace of mind.</p>
                            <p>Biladl is the all encompassing Legal portal consisting of a collaboration of individual Lawyers, boutique Law firms which is country specific from different countries respectively and large international law firms all designed to provide Legal services by Membership Only via combination of online call center for Assistance advice and assessment for members legal queries as well as an App based digitized concept which assists members by referring them to the correct legal solution for their problems.</p>
                            <p>Biladl is constantly teaming up with the most esteemed and respected law firms in their respective countries as well as individuals lawyers who have expertise in every field of law to give our members the best advice and legal service available, at an affordable price. At Biladl our commitment is to give our Members the best legal advice when and where you need it.</p>
                            <hr />
                            <blockquote>
                            <span class="quote-text">
                           Problems remain Problems until you get connected to Biladl
                            </span>
                            </blockquote>
                            <p>Due to lack of knowledge about one’s legal rights, handling and tackling such issues legally becomes a big challenge. Everyone can’t afford to acquire legal services both in terms of their valuable time and hard-earned money.</p>
                        </div>
					</div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    </div>
</div>
</div>
      <!-- Page Header Start -->
      <div class="page-header" style="background: url(<?=base_url();?>assets/website/img/banner1.jpg);">
        <div class="container">
          <div class="row">         
            <div class="col-md-12">
              <div class="breadcrumb-wrapper">
                <h2 class="product-title">Membership Plans</h2>
                <ol class="breadcrumb">
                  <li><a href="#"><i class="ti-home"></i> Home</a></li>
                  <li class="current">Membership Plans</li>
                </ol>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- Page Header End -->        

      <!-- Main container Start -->  
      <div class="about section">
        <div class="container">
          <div class="row"> 
            <div class="col-md-12">
                <h4>Your BILADL Membership provides you with many benefits to live life to the fullest with Peace of Mind </h4>
                <p>Membership plans include</p>
                <p>Legal Counseling and Assistance for </p>
                <ul class="bil-list">
                    <li>Civil matters
                    <li>Criminal matters </li>
                    <li>Labour related </li>
                    <li>Family matters </li>
                    <li>Counseling on court procedure </li>
                    <li>Debt relief like settlement negotiations etc</li>
                    <li>Financial advice and Consults</li>
                    <li>Negotiations with third parties in any agreement and contracts </li>
                </ul>
                <br />
                <p>Your Membership gives you the Freedom to live Life Peacefully as Our LegalAdvizors advise and guide you in all your daily legal transaction matters .</p>
                
                <h3>GOLD</h3>
                <p><h4>SAR 49 per month</h4> gives you.</p> 
                <ul class="bil-list">
                    <li>Face-to-face consultation with BILADL to answer any of your legal questions.</li>
                    <li>Access to our attorneys who will represent you, Should your matter need representation in court or Alternative Dispute Resolution Forums such as the Labour Courts etc.</li>
                    <li>24-hour legal assistance via our legal line, 7 days a week and 365 days a year (e.g. help for urgent bail applications) as well as online legal assistance during office hours</li>
                </ul>
                <p class="m-p p-10"> Matters that BILADL will assist you with:</p>
                <ul class="bil-list">
                    <li>Car Accident Insurance problems</li>
                    <li>Consumer related problems (e.g. guarantees and defective goods)</li>
                    <li>Home-owner problems (e.g. faulty alterations, home improvements, defective building works)</li>
                    <li>Job related matters (e.g. unfair dismissals, unfair retrenchments)</li>
                    <li>Wrongful Criminal charges against our Member(Subject to Assessment)</li>
                    <li>Motor vehicle problems and accident claims</li>
                    <li>Personal injury claims</li>
                </ul>
                <h3>Extended benefits:</h3>
                <p class="m-p p-10">BILADL strive to assist with any legal matters or questions you may have, even if they are not covered by your BILADL Membership such as:</p>
                <ul class="bil-list">
                    <li>Debt services (e.g. settlement negotiations, debt counselling, rescission of administration orders and judgments)</li>
                    <li>Family Matters (e.g. unopposed divorces, child maintenance matters)</li>
                    <li>Other civil Matters (e.g. mediation or referrals to Alternative Dispute Resolution forums such as the, preparation and referral to Small Claims Court)</li>
                </ul>
                
                
                <h3>GOLDPLUS </h3>
                <p><h4>SAR 149 per month</h4> GoldPlus Membership will provide you all the benefits of Gold Membership Plus...</p> 
                <p>Legal Emergency Fast Track - an added legal benefit giving you an immediate ONE hour consultation per year with a lawyer at no extra charge. You can use it for any matter whether covered by the plan or not</p>
                <p>And everything else that the Gold Membership offers:</p>
                <ul class="bil-list">
                    <li>Face-to-face consultation with BILADL</li>
                    <li>Access to attorneys who will represent you, should your matter need representation in court or Alternative Dispute Resolution Forums such as Labour Courts etc.</li>
                    <li>24-hour legal assistance via our legal line, 7 days a week and 365 days a year (e.g., help for urgent with bail application), as well as online legal assistance during office hours</li>
                </ul>
                
                <h3>PLATINUM</h3>
                <p><h4>SAR 249 per month</h4></p> 
                <p>PLATINUM Membership will provide you all the benefits of Gold Membership Plus...:</p>
                <ul class="bil-list">
                    <li>Face-to-face consultations with BILADL</li>
                    <li>Access to our network of attorneys who will represent you, should your matter need representation in court or Alternative Dispute Resolution Forums such as the Labour Courts etc</li>
                    <li>24-hour legal assistance via our legal line, 7 days a week and 365 days a year (such as help with bail applications) as well as online legal assistance during office hours</li>
                </ul>
                <h4>Exclusive to Platinum Membership</h4>
                <ul>
                    <li>Representation by our highly qualified and experienced attorneys:</li>
                    <li>At the Regional/High Court for unopposed or uncontested divorce, subject to a 6-month waiting period</li>
                    <li>At the Maintenance Court for child maintenance matters, subject to a 3-month waiting period</li>
                    <li>For settlement negotiations (Alternative Dispute Resolution), subject to a 3-month waiting period</li>
                    <li>Up to 60% discount on initiation fee for debt counselling (3-month waiting period)
                    <li>Up to 60% discount on property transfer fee (no waiting period)</li>
                    <li>One FREE property evaluation assessment per annum</li>
                    <li>Rescission of Administration Orders (3-month waiting period)</li>
                    <li>Legal cover for drafting and registration of your Ante-nuptial Marriage contract (3-month waiting period)</li>
                    <li>Legal cover for drafting of basic wills and testaments (3-month waiting period)</li>
                </ul>
                
            </div>
          </div>
        </div>
      </div>
      <!-- Main container End -->  
      <!-- Page Header Start -->
      <div class="page-header" style="background: url(<?=base_url('assets/website/img/banner1.jpg');?>);">
        <div class="container">
          <div class="row">         
            <div class="col-md-12">
              <div class="breadcrumb-wrapper">
                <h2 class="product-title">سياسة خاصة</h2>
                <ol class="breadcrumb">
                  <li><a href="<?=base_url('arbic/');?>"><i class="ti-home"></i> الصفحة الرئيسية</a></li>
                  <li class="current">سياسة خاصة</li>
                </ol>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- Page Header End -->        

    <section class="section">
          <div class="container p-policy">
                <p>PLEASE READ THESE TERMS AND CONDITIONS CAREFULLY. BY ACCESSING OR USING THIS WEB SITE, USERS AGREE TO BE BOUND BY THE TERMS AND CONDITIONS INCLUDED HEREIN AND ALL TERMS, CONDITIONS, AND DISCLOSURES INCORPORATED HEREIN BY REFERENCE. IF USERS DO NOT AGREE TO ALL OF THESE TERMS AND CONDITIONS, DO NOT USE THIS WEBSITE. THE USE OF THE WEBSITE CONSTITUTES YOUR AGREEMENT TO THESE TERMS AND CONDITIONS.

These Terms and Conditions (also referred to as “Site Terms" and “Agreement” herein) apply exclusively to Users access to, and use of, the website operated by ……………….., located at www.biladl.com and the information and other services provided therein (the "Services"). These Site Terms do not alter the terms or conditions of any other agreement Users may have with BILADL, or its subsidiaries or affiliates, for products, services or otherwise. If Users are using the Site on behalf of any person or entity, Users must legally represent and warrant that they are appointed authorized to sign up to BILADL’s Site Terms on such entity's behalf, and that such entity agrees to indemnify Users and BILADL for violations of these Site Terms.</p>
                





            </div>
          </div>
    </section>
